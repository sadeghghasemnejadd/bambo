export const loginApi = "http://localhost:5000/api/auth/login";
export const registerApi = "http://localhost:5000/api/auth/register";
export const getStudnetByIdApi = "http://localhost:5000/api/student/";
export const contactUsApi = "http://localhost:5000/api/contactUs";
export const sendComment = "http://localhost:5000/api/comments/send";