export const HOME_ROUTE = "/home";
export const COURSES_ROUTE = "/courses";
export const COURSE_ROUTE = "/course";
export const LOGIN_ROUTE = "/login";
export const REGISTER_ROUTE = "/register";
export const SHOP_ROUTE = "/shop";
